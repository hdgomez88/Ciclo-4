import Medicamento from "../../models/historia_clinica/Medicamento.js";

const agregar= async(req, res) => {
    console.log("respuesta desde el metodo agregar");
}

const listar= async(req, res) => {
    console.log("respuesta desde el metodo listar");
}

const eliminar= async(req, res) => {
    console.log("respuesta desde el metodo eliminar");
}

const editar= async(req, res) => {
    console.log("respuesta desde el metodo editar");
}

const listarUno= async(req, res) => {
    console.log("respuesta desde el metodo listarUno");
}

export {
    agregar,
    listar,
    eliminar,
    editar,
    listarUno
}